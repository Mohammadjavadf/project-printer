document.addEventListener('DOMContentLoaded', function() {
    renderCart();
});

function renderCart() {
    const cartItems = document.getElementById('cart-items');
    const totalPrice = document.getElementById('total-price');
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    cartItems.innerHTML = '';
    let total = 0;

    cart.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><a href="product-details.html?id=${item.id}">${item.name}</a></td>
            <td>${item.quantity}</td>
            <td>${item.price} تومان</td>
            <td>${item.price * item.quantity} تومان</td>
            <td><button class="delete-button" onclick="removeFromCart(${item.id})">حذف</button></td>
        `;
        cartItems.appendChild(row);
        total += item.price * item.quantity;
    });

    totalPrice.innerText = total;
}

function removeFromCart(id) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart = cart.filter(item => item.id !== id);
    localStorage.setItem('cart', JSON.stringify(cart));
    renderCart();
}

function checkout() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    if (cart.length === 0) {
        alert('سبد خرید شما خالی است');
        return;
    }

    // اینجا می‌توانید درگاه پرداخت خود را اضافه کنید

    alert('درگاه پرداخت به زودی اضافه خواهد شد');
}
