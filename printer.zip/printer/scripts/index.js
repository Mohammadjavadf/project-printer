function redirectToProducts() {
    const searchTerm = document.getElementById('searchInput').value;
    if (searchTerm) {
        window.location.href = `pages/products.html?search=${encodeURIComponent(searchTerm)}`;
    } else {
        alert('لطفاً کلمه‌ای برای جستجو وارد کنید');
    }
}
