document.getElementById('showSignUp').addEventListener('click', function() {
    document.querySelector('.sign-in-container').style.display = 'none';
    document.querySelector('.sign-up-container').style.display = 'block';
});

document.getElementById('showSignIn').addEventListener('click', function() {
    document.querySelector('.sign-up-container').style.display = 'none';
    document.querySelector('.sign-in-container').style.display = 'block';
});

// ذخیره کاربران ثبت‌نام شده
let users = JSON.parse(localStorage.getItem('users')) || [];

// ارسال فرم ورود
document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    const user = users.find(user => user.email === email && user.password === password);
    if (user) {
        alert('ورود با موفقیت انجام شد');
        localStorage.setItem('currentUser', JSON.stringify(user));
        updateUserInterface(user.name);
        window.location.href = '/index.html'; // هدایت به صفحه اصلی
    } else {
        alert('کاربری با این اطلاعات وجود ندارد');
    }
});

// ارسال فرم ثبت‌نام
document.getElementById('signUpForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email-signup').value;
    const phone = document.getElementById('phone').value;
    const password = document.getElementById('password-signup').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const terms = document.getElementById('terms').checked;

    if (password !== confirmPassword) {
        alert('رمز عبور و تکرار آن یکسان نیستند');
        return;
    }

    const newUser = { name, email, phone, password, terms };
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    alert('ثبت‌نام با موفقیت انجام شد');
    document.getElementById('showSignIn').click();
});

// به‌روزرسانی رابط کاربری پس از ورود
function updateUserInterface(userName) {
    document.getElementById('auth-links').style.display = 'none';
    const userInfo = document.getElementById('user-info');
    userInfo.style.display = 'block';
    document.getElementById('user-name').innerText = userName;
}

// بارگذاری اطلاعات کاربر از Local Storage
window.addEventListener('load', () => {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (currentUser) {
        updateUserInterface(currentUser.name);
    }
});
