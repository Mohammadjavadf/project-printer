document.addEventListener('DOMContentLoaded', () => {
    // اسکریپت‌های مربوط به پنل مدیریت
});

function addProduct() {
    // کد اضافه کردن محصول جدید
}

function editProduct() {
    // کد ویرایش محصول
}

function deleteProduct() {
    // کد حذف محصول
}

function viewUsers() {
    // کد مشاهده کاربران
}
