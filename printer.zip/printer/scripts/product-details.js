let selectedProducts = JSON.parse(localStorage.getItem("selectedProducts")) || [];

document.addEventListener("DOMContentLoaded", function () {
  const urlParams = new URLSearchParams(window.location.search);
  const productId = urlParams.get("id");
  if (productId) {
    loadProductDetails(productId);
  }

  const compareButton = document.getElementById("compareButton");
  if (compareButton) {
    compareButton.addEventListener("click", showComparisonBox);
  }

  // بارگذاری محصولات انتخاب شده از localStorage
  updateFloatingComparisonBox();
});

async function loadProductDetails(id) {
  try {
    const response = await fetch("../data/products.json");
    const products = await response.json();
    const product = products.find((p) => p.id == id);
    if (product) {
      document.title = product.name;
      document.getElementById("productName").textContent = product.name;
      document.getElementById("productModel").textContent = `مدل: ${product.model}`;
      document.getElementById("productPrice").textContent = `قیمت: ${product.price} تومان`;
      document.getElementById("productDescription").textContent = `توضیحات: ${product.description}`;
      document.getElementById("addToCartButton").addEventListener("click", function () {
        addToCart(product.id, product.name, product.price);
      });
      // اضافه کردن محصول به مقایسه به صورت پیش فرض
      if (!selectedProducts.some((p) => p.id === product.id)) {
        selectedProducts.push(product);
        localStorage.setItem("selectedProducts", JSON.stringify(selectedProducts));
        updateFloatingComparisonBox();
      }
    } else {
      alert("محصول مورد نظر یافت نشد");
    }
  } catch (error) {
    console.error("خطا در بارگذاری مشخصات محصول:", error);
  }
}

function addToCart(id, name, price) {
  const cart = JSON.parse(localStorage.getItem("cart")) || [];
  const existingItem = cart.find((item) => item.id === id);
  if (existingItem) {
    existingItem.quantity++;
  } else {
    cart.push({ id, name, price, quantity: 1 });
  }
  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartCount(); // به‌روزرسانی تعداد محصولات در سبد خرید بعد از اضافه کردن محصول
  alert(`محصول ${name} به سبد خرید اضافه شد`);
}

// تابع به‌روزرسانی تعداد محصولات در سبد خرید
const updateCartCount = () => {
  const cart = JSON.parse(localStorage.getItem("cart")) || [];
  const totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartCount = document.getElementById('cart-count');
  if (cartCount) {
    cartCount.textContent = totalCount;
  }
};

// فراخوانی به‌روزرسانی تعداد محصولات در بارگذاری صفحه
document.addEventListener('DOMContentLoaded', () => {
  updateCartCount();
  // سایر کدهای موجود...
});

const showComparisonBox = () => {
  const floatingBox = document.getElementById("floatingComparisonBox");
  floatingBox.style.display = "block";
  updateFloatingComparisonBox();
};

const showProductList = () => {
  const compareListContainer = document.querySelector(".compare-list-container");
  compareListContainer.style.display = "block";

  fetch("../data/products.json")
    .then((response) => response.json())
    .then((products) => {
      const compareList = document.querySelector(".compare-list");
      compareList.innerHTML = "";
      products.forEach((product) => {
        const productItem = document.createElement("div");
        productItem.classList.add("product-item");
        productItem.innerHTML = `
          <div>
            <img src="../images/products/${product.image}" alt="${product.name}" style="width: 50px; height: auto; vertical-align: middle;">
            <span>${product.name}</span>
          </div>
          <button onclick="selectProduct(${product.id})">انتخاب برای مقایسه</button>
        `;
        compareList.appendChild(productItem);
      });
    })
    .catch((error) => console.error("خطا در بارگذاری لیست محصولات:", error));
};

const selectProduct = (productId) => {
  fetch("../data/products.json")
    .then((response) => response.json())
    .then((products) => {
      const product = products.find((p) => p.id === productId);
      if (!selectedProducts.some((p) => p.id === productId)) {
        selectedProducts.push(product);
        localStorage.setItem("selectedProducts", JSON.stringify(selectedProducts));
        updateFloatingComparisonBox();
      } else {
        alert("این محصول قبلاً برای مقایسه انتخاب شده است.");
      }
      const compareListContainer = document.querySelector(".compare-list-container");
      compareListContainer.style.display = "none"; // بستن لیست محصولات پس از انتخاب
    })
    .catch((error) => console.error("خطا در انتخاب محصول:", error));
};

const updateFloatingComparisonBox = () => {
  const floatingBox = document.getElementById("floatingComparisonBox");
  const comparisonGrid = floatingBox.querySelector(".comparison-grid");
  comparisonGrid.innerHTML = selectedProducts
      .map(
          (product) => `
          <div class="comparison-item">
              <img src="../images/products/${product.image}" alt="${product.name}">
              <h4>${product.name}</h4>
              <p>قیمت: ${product.price} تومان</p>
              <p>مدل: ${product.model}</p>
              <p>توضیحات: ${product.description}</p>
              <button onclick="removeProduct(${product.id})">حذف</button>
          </div>
      `
      )
      .join("");
};


const removeProduct = (productId) => {
  selectedProducts = selectedProducts.filter((p) => p.id !== productId);
  localStorage.setItem("selectedProducts", JSON.stringify(selectedProducts));
  updateFloatingComparisonBox();
  if (selectedProducts.length === 0) {
    document.getElementById("floatingComparisonBox").style.display = "none";
  }
};

const closeComparisonBox = () => {
  const floatingBox = document.getElementById("floatingComparisonBox");
  floatingBox.style.display = "none"; // بستن باکس
};

const closeModal = () => {
  document.getElementById("comparisonModal").style.display = "none";
};

window.addEventListener("click", (event) => {
  const modal = document.getElementById("comparisonModal");
  if (event.target === modal) {
    modal.style.display = "none";
  }
});

function goBack() {
  window.history.back();
}

