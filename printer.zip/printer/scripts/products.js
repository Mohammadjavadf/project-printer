document.addEventListener('DOMContentLoaded', () => {
    const categoryFilter = document.getElementById('categoryFilter');
    const priceFilter = document.getElementById('priceFilter');
    const productList = document.querySelector('.product-list');
    const loadMoreButton = document.createElement('button');
    loadMoreButton.textContent = 'محصولات بیشتر';
    loadMoreButton.classList.add('load-more-button');
    let productsPerPage = 20; // تعداد محصولات در هر صفحه
    let currentPage = 1;

    loadMoreButton.addEventListener('click', () => {
        currentPage++;
        filterProducts();
    });

    const urlParams = new URLSearchParams(window.location.search);
    const searchQuery = urlParams.get('search');

    fetch('../data/products.json')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(products => {
            const renderProducts = (filteredProducts) => {
                productList.innerHTML = '';
                const startIndex = (currentPage - 1) * productsPerPage;
                const endIndex = startIndex + productsPerPage;
                const paginatedProducts = filteredProducts.slice(startIndex, endIndex);
                paginatedProducts.forEach(product => {
                    const productItem = document.createElement('div');
                    productItem.classList.add('product-item');
                    productItem.innerHTML = `
                        <a href="product-details.html?id=${product.id}">
                            <img src="../images/products/${product.image}" alt="${product.name}">
                            <h3>${product.name}</h3>
                            <p>${product.price} تومان</p>
                        </a>
                        <button onclick="addToCart(${product.id}, '${product.name}', ${product.price})">افزودن به سبد خرید</button>
                    `;
                    productList.appendChild(productItem);
                });
                if (filteredProducts.length > endIndex) {
                    productList.appendChild(loadMoreButton);
                } else {
                    loadMoreButton.style.display = 'none';
                }
            };

            const filterProducts = () => {
                let filteredProducts = products;
                const category = categoryFilter.dataset.category || 'all';
                if (category !== 'all') {
                    filteredProducts = filteredProducts.filter(product => product.category === category);
                }
                if (priceFilter && priceFilter.value === 'lowToHigh') {
                    filteredProducts = filteredProducts.sort((a, b) => a.price - b.price);
                } else if (priceFilter && priceFilter.value === 'highToLow') {
                    filteredProducts = filteredProducts.sort((a, b) => b.price - a.price);
                }
                if (searchQuery) {
                    filteredProducts = filteredProducts.filter(product => {
                        const productName = product.name ? product.name.toLowerCase() : '';
                        const productModel = product.model ? product.model.toLowerCase() : '';
                        return productName.includes(searchQuery) || productModel.includes(searchQuery);
                    });
                }
                renderProducts(filteredProducts);
            };

            filterProducts(); // نمایش ابتدایی محصولات

            document.querySelectorAll('.category-main').forEach(link => {
                link.addEventListener('click', (event) => {
                    event.preventDefault();
                    const subCategoryMenu = event.target.nextElementSibling;
                    if (subCategoryMenu.style.display === 'block') {
                        subCategoryMenu.style.display = 'none';
                    } else {
                        document.querySelectorAll('.sub-category').forEach(menu => {
                            menu.style.display = 'none';
                        });
                        subCategoryMenu.style.display = 'block';
                    }
                });
            });

            document.querySelectorAll('.sub-category a').forEach(link => {
                link.addEventListener('click', (event) => {
                    event.preventDefault();
                    const category = event.target.getAttribute('data-category');
                    if (category) {
                        categoryFilter.dataset.category = category;
                        categoryFilter.textContent = event.target.textContent;
                        currentPage = 1;
                        filterProducts();
                    }
                });
            });

            if (priceFilter) {
                priceFilter.addEventListener('change', () => {
                    currentPage = 1;
                    filterProducts();
                });
            }
        })
        .catch(error => {
            console.error("Error fetching products:", error);
            productList.innerHTML = '<p>مشکلی در بارگذاری محصولات وجود دارد.</p>';
        });

    updateCartCount(); // فراخوانی به‌روزرسانی تعداد محصولات در بارگذاری صفحه
});

function searchProducts() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const productList = document.querySelector('.product-list');
    const products = Array.from(productList.getElementsByClassName('product-item'));

    products.forEach(product => {
        const productName = product.getElementsByTagName('h3')[0].innerText.toLowerCase();
        if (productName.includes(searchTerm)) {
            product.style.display = 'block';
        } else {
            product.style.display = 'none';
        }
    });
}

// تابع به‌روزرسانی تعداد محصولات در سبد خرید
const updateCartCount = () => {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
    const cartCount = document.getElementById('cart-count');
    if (cartCount) {
        cartCount.textContent = totalCount;
    }
};

function addToCart(id, name, price) {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const existingItem = cart.find(item => item.id === id);
    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({ id, name, price, quantity: 1 });
    }
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount(); // به‌روزرسانی تعداد محصولات در سبد خرید بعد از اضافه کردن محصول
    alert(`محصول ${name} به سبد خرید اضافه شد`);
}

