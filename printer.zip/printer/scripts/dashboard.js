document.addEventListener('DOMContentLoaded', function() {
    loadProducts();
});

function loadProducts() {
    fetch('../data/products.json')
        .then(response => response.json())
        .then(products => {
            const productList = document.querySelector('.product-list');
            productList.innerHTML = '';
            products.forEach(product => {
                const productItem = document.createElement('div');
                productItem.classList.add('product-item');
                productItem.innerHTML = `
                    <div>
                        <img src="../images/products/${product.image}" alt="${product.name}">
                        <h3>${product.name}</h3>
                        <p>${product.price} تومان</p>
                    </div>
                    <div>
                        <button onclick="editProduct(${product.id})">ویرایش</button>
                        <button onclick="deleteProduct(${product.id})">حذف</button>
                    </div>
                `;
                productList.appendChild(productItem);
            });
        })
        .catch(error => console.error('خطا در بارگذاری محصولات:', error));
}

function showAddProductForm() {
    document.getElementById('formTitle').textContent = 'افزودن محصول جدید';
    document.getElementById('productForm').reset();
    document.getElementById('productFormContainer').style.display = 'block';
}

function saveProduct(event) {
    event.preventDefault();
    const productForm = document.getElementById('productForm');
    const formData = new FormData(productForm);
    const newProduct = {
        id: formData.get('id') || Date.now().toString(),
        name: formData.get('name'),
        model: formData.get('model'),
        price: formData.get('price'),
        description: formData.get('description'),
        image: formData.get('image').name || 'default.jpg'
    };

    const productId = formData.get('id');
    const method = productId ? 'PUT' : 'POST';
    const url = productId ? `../data/products.json/${productId}` : '../data/products.json';

    fetch(url, {
        method: method,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(newProduct)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('خطا در ذخیره محصول');
        }
        return response.json();
    })
    .then(() => {
        loadProducts();
        document.getElementById('productFormContainer').style.display = 'none';
    })
    .catch(error => console.error('خطا در ذخیره محصول:', error));
}

function editProduct(id) {
    fetch('../data/products.json')
        .then(response => response.json())
        .then(products => {
            const product = products.find(p => p.id == id);
            if (product) {
                document.getElementById('formTitle').textContent = 'ویرایش محصول';
                document.getElementById('productId').value = product.id;
                document.getElementById('productName').value = product.name;
                document.getElementById('productModel').value = product.model;
                document.getElementById('productPrice').value = product.price;
                document.getElementById('productDescription').value = product.description;
                document.getElementById('productFormContainer').style.display = 'block';
            }
        })
        .catch(error => console.error('خطا در بارگذاری محصول:', error));
}

function deleteProduct(id) {
    fetch(`../data/products.json/${id}`, {
        method: 'DELETE'
    })
    .then(() => loadProducts())
    .catch(error => console.error('خطا در حذف محصول:', error));
}

function cancelForm() {
    document.getElementById('productFormContainer').style.display = 'none';
}

