const toggleMenu = () => {
    const navMenu = document.getElementById('nav-menu');
    navMenu.classList.toggle('active');
};
