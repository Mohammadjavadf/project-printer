let currentSlide = 0;
const slides = document.querySelectorAll('.slide');

const showSlide = (index) => {
    slides.forEach((slide, i) => {
        slide.classList.toggle('active', i === index);
    });
};

const nextSlide = () => {
    currentSlide = (currentSlide + 1) % slides.length;
    showSlide(currentSlide);
    resetSlideShow();
};

const prevSlide = () => {
    currentSlide = (currentSlide - 1 + slides.length) % slides.length;
    showSlide(currentSlide);
    resetSlideShow();
};

let slideTimeout;

const resetSlideShow = () => {
    clearTimeout(slideTimeout);
    slideTimeout = setTimeout(nextSlide, 3000); // تغییر خودکار اسلایدها هر 3 ثانیه
};

document.addEventListener('DOMContentLoaded', () => {
    showSlide(currentSlide); // نمایش اولین اسلاید بلافاصله
    resetSlideShow(); // شروع اسلایدشو خودکار
});
