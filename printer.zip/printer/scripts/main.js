// $(document).ready(function(){
//     $('.slider').slick({
//         autoplay: true,
//         autoplaySpeed: 3000,
//         dots: true,
//         arrows: true,
//         prevArrow: '<span class="prev">&lt;</span>',
//         nextArrow: '<span class="next">&gt;</span>',
//     });
// });
