const searchProducts = () => {
    const searchInput = document.getElementById('searchInput').value.toLowerCase();
    const productList = document.querySelector('.product-list');
    fetch('../data/products.json')
        .then(response => response.json())
        .then(products => {
            const filteredProducts = products.filter(product => {
                const productName = product.name ? product.name.toLowerCase() : '';
                const productModel = product.model ? product.model.toLowerCase() : '';
                return productName.includes(searchInput) || productModel.includes(searchInput);
            });

            productList.innerHTML = filteredProducts.map(product => `
                <div class="product-item">
                    <a href="product-details.html?id=${product.id}">
                        <img src="../images/products/${product.image}" alt="${product.name}">
                        <h3>${product.name}</h3>
                        <p>${product.price} تومان</p>
                    </a>
                </div>
            `).join('');
        })
        .catch(error => {
            console.error("Error fetching products:", error);
            productList.innerHTML = '<p>مشکلی در بارگذاری محصولات وجود دارد.</p>';
        });
};
